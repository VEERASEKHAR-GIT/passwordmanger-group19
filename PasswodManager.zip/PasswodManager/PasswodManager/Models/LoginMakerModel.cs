﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PasswodManager.Models
{
    public class LoginIdentityModel
    {
        public String identity { get; set; }
        public String password { get; set; }
    }
}
