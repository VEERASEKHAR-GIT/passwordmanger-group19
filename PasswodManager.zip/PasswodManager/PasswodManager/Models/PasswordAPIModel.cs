﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PasswodManager.Models
{
    public class PasswordItem
    {
        public string app { get; set; }
        public string collectionId { get; set; }
        public string collectionName { get; set; }
        public string created { get; set; }
        public string id { get; set; }
        public string password { get; set; }
        public string updated { get; set; }
        public string userId { get; set; }
    }

    public class PasswordApiModel
    {
        public int page { get; set; }
        public int perPage { get; set; }
        public int totalItems { get; set; }
        public int totalPages { get; set; }
        public List<PasswordItem> items { get; set; }
    }


}
