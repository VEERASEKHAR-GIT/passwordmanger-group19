﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PasswodManager.Models
{
    public class Record
    {
        public string id { get; set; }
        public string collectionId { get; set; }
        public string collectionName { get; set; }
        public string created { get; set; }
        public string updated { get; set; }
        public string username { get; set; }
        public bool verified { get; set; }
        public bool emailVisibility { get; set; }
        public string email { get; set; }
        public string name { get; set; }
        public string avatar { get; set; }
    }

    public class AuthModel
    {
        public string token { get; set; }
        public Record record { get; set; }
    }
}
