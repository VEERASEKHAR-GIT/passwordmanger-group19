﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PasswodManager.Models
{
    public class LoginModel
    {
        public String email { get; set; }
        public String password { get; set; }
        public String passwordConfirm { get; set; }

    }
}
