﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PasswodManager.Models
{
    public class PasswordPostModel
    {
        public string app { get; set; }
        public string userId { get; set; }
        public string password { get; set; }
    }
}
